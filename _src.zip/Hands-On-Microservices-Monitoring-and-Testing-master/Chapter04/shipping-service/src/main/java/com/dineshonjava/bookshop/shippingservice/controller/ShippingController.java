/**
 * 
 */
package com.dineshonjava.bookshop.shippingservice.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * @author Dinesh.Rajput
 *
 */
@RestController
public class ShippingController {

}
