/**
 * 
 */
package com.dineshonjava.bookshop.shippingservice.service;

/**
 * @author Dinesh.Rajput
 *
 */
//@FeignClient("order-service")
public interface OrderService {

}
