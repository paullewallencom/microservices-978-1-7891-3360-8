/**
 * 
 */
package com.dineshonjava.bookshop.orderservice.service;

/**
 * @author Dinesh.Rajput
 *
 */
//@FeignClient("book-service")
public interface BookService {

}
