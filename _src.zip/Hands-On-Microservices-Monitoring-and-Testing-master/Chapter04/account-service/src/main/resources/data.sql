INSERT INTO ACCOUNT (accountId, NAME, ADDRESS, EMAIL, MOBILE) values (1000, 'Dinesh Rajput', 'K-12, Sector 13, Noida', 'dineshxxx@gmail.com', '99312XXX12');
INSERT INTO ACCOUNT (accountId, NAME, ADDRESS, EMAIL, MOBILE) values (1001, 'Anamika Rajput', 'M-15, Sector 15, Noida', 'anamikaxxx@gmail.com', '67312XXX12');
INSERT INTO ACCOUNT (accountId, NAME, ADDRESS, EMAIL, MOBILE) values (1002, 'Arnav Rajput', 'N-19, Sector 17, Mumbai', 'arnavxxx@gmail.com', '54312XXX12');
INSERT INTO ACCOUNT (accountId, NAME, ADDRESS, EMAIL, MOBILE) values (1003, 'Rushika Rajput', 'O-10, Sector 11, New Delhi', 'rushikaxxx@gmail.com', '99232XXX12');
INSERT INTO ACCOUNT (accountId, NAME, ADDRESS, EMAIL, MOBILE) values (1004, 'Adesh Rajput', 'P-14, Sector 10, Greater Noida', 'adeshxxx@gmail.com', '99312XXX12');
INSERT INTO ACCOUNT (accountId, NAME, ADDRESS, EMAIL, MOBILE) values (1005, 'Vinesh Rajput', 'C-32, Sector 43, Gurugram', 'vineshxxx@gmail.com', '92332XXX12');
